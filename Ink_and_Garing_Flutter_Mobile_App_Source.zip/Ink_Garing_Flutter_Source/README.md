# Ink & Garing — Flutter mobile app source

This is a Flutter Android/iOS source project, not a website and not yet a compiled APK/IPA.

Features in this source: navy/cream/blush styling, Afrikaans branding and slogan, local SQLite inventory, item photos, sales with automatic stock reduction, owner-share and payout records, stock history, event name/date countdown, and printable PDF reports.

## Build requirements
Install Flutter stable and Android Studio. For iOS compilation/signing, a Mac with Xcode is required.

## Build Android APK
From this directory:
```sh
flutter pub get
flutter run
flutter build apk --release
```
For iOS on macOS:
```sh
flutter build ios --release
```
iOS installation/distribution requires Apple signing and a supported distribution method.

## Important
Source needs `flutter pub get`, compilation and device testing before use with real shop data. Local SQLite data stays on that device and does not sync. The logo artwork should be replaced with the approved first protea logo once that exact image is available.
